//Set the color to use on the code
const Colors = {
  accent300: "#f5f5dc",
  accent500: "#01ac40",
  primary300o5: "rgba(236, 236, 219, 0.5)",
  primary300: "#f4f4b2",
  primary500: "#228B22",
  primary800: "#571d0c",
};

export default Colors;
