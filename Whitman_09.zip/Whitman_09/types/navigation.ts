export type RootStackParamList = {
  Home: undefined;
  DestinationsOverview: { 
    countryId: string;
    countryName?: string; 
  };
};